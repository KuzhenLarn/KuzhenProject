<?php
session_start();
require_once 'common.php';

define('TIMEZONE', 'Europe/Kyiv');

date_default_timezone_set(TIMEZONE);

function linkifyText($text) {
    $text = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    $pattern = '/\b((https?:\/\/|www\.)[^\s<]+)/i';

    return preg_replace_callback($pattern, function($matches) {
        $url = $matches[1];
        $href = preg_match('~^https?://~i', $url) ? $url : 'http://'.$url;
        $href = htmlspecialchars($href, ENT_QUOTES, 'UTF-8');
        $label = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
        return "<a href='$href' target='_blank' rel='noopener noreferrer'>$label</a>";
    }, $text);
}

function append_system_message($message) {
    $fp = fopen('log.html', 'a');
    if ($fp) {
        fwrite($fp, "<div class='msgln system-msg'><i>" . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . "</i><br></div>\n");
        fclose($fp);
    }
}

function append_chat_break() {
    file_put_contents('log.html', "<div class='msgln chat-break'><br></div>\n", FILE_APPEND | LOCK_EX);
}

function remove_online_user($name) {
    $users = load_json_file('online.json');
    unset($users[$name]);
    file_put_contents('online.json', json_encode($users), LOCK_EX);
}

function help_message($name) {
    $role = is_admin($name) ? 'admin' : (is_operator($name) ? 'operator' : 'user');
    $sections = [
        'Основні' => [
            'help - ця довідка'
        ],
        'Пароль' => [
            'password пароль - встановити пароль',
            'password off - вимкнути пароль',
        ],
        'Інтерфейс' => [
            'ui input колір/URL - фон поля вводу',
            'ui center колір/URL - фон центру чату',
            'ui input-text колір - колір тексту вводу',
            'ui center-text колір - колір тексту центру',
            'ui input-hover колір - hover поля вводу',
            'ui center-hover колір - hover центру чату',
            'ui input-opacity 0-1 - затемнення фону поля',
            'ui center-opacity 0-1 - затемнення фону центру',
            'ui img-bg колір - фон кнопки файлу',
            'ui img-hover колір - hover кнопки файлу',
            'ui send-bg колір - фон кнопки відправки',
            'ui send-hover колір - hover кнопки відправки',
            'ui exit-hover колір - hover кнопки виходу',
            'ui img-icon URL - іконка кнопки файлу',
            'ui img-icon-hover URL - hover-іконка кнопки файлу',
            'ui send-icon URL - іконка кнопки відправки',
            'ui send-icon-hover URL - hover-іконка кнопки відправки',
            'ui exit-icon URL - іконка кнопки виходу',
            'ui exit-icon-hover URL - hover-іконка кнопки виходу',
            'ui reset - заводські налаштування'
        ]
    ];

    if ($role === 'admin') {
        $sections['Основні'][] = 'br - вставити відступ';
        $sections['Стилі'] = [
            'style Нік name|text|a|block|border|time колір',
            'style Нік all колір',
            'style block колір1 колір2 кут'
        ];
        $sections['Модерація'] = [
            'clear a - очистити весь чат',
            'clear s - очистити системні повідомлення',
            'kick Нік - відключити користувача',
            'op Нік - призначити оператора',
            'ope Нік - зняти права оператора',
            'ad Нік - призначити адміністратора',
            'ade Нік - зняти права адміністратора'
        ];
    } elseif ($role === 'operator') {
        $sections['Основні'][] = 'br - вставити відступ';
        $sections['Модерація'] = [
            'clear a - очистити весь чат',
            'clear s - очистити системні повідомлення',
            'kick Нік - відключити користувача'
        ];
    }
    $html = '<div class="private-help-title">Команди Klabc</div>';
    foreach ($sections as $title => $lines) {
        $html .= '<div class="private-help-section"><b>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</b>';
        foreach ($lines as $line) {
            $html .= '<div>' . htmlspecialchars($line, ENT_QUOTES, 'UTF-8') . '</div>';
        }
        $html .= '</div>';
    }
    return "<div class='private-help'>" . $html . '</div>';
}

function handle_command($text, $name) {
    if ($text === '') {
        return false;
    }

    $parts = preg_split('/\s+/', trim($text), 6);
    $command = ltrim(strtolower($parts[0]), '/');

    if ($command === 'help') {
        return help_message($name);
    }

    if ($command === 'br') {
        if (can_moderate($name)) {
            append_chat_break();
        }
        return true;
    }

    if ($command === 'password' || $command === 'пароль') {
        $profiles = load_profiles();
        if (!isset($profiles[$name]) || !is_array($profiles[$name])) {
            $profiles[$name] = [];
        }
        $secret = isset($parts[1]) ? trim($parts[1]) : '';
        if ($secret === 'off' || $secret === 'none') {
            unset($profiles[$name]['password_hash']);
            unset($profiles[$name]['login_token_hash']);
            setcookie('klabc_profile_token', '', time() - 3600, '/', '', false, true);
            append_system_message('Пароль для ' . $name . ' вимкнено.');
        } elseif (strlen($secret) >= 4) {
            $profiles[$name]['password_hash'] = password_hash($secret, PASSWORD_DEFAULT);
            unset($profiles[$name]['login_token_hash']);
            setcookie('klabc_profile_token', '', time() - 3600, '/', '', false, true);
            append_system_message('Пароль для ' . $name . ' встановлено.');
        } else {
            append_system_message('Пароль має містити щонайменше 4 символи.');
        }
        save_profiles($profiles);
        return true;
    }

    if ($command === 'ui') {
        $profiles = load_profiles();
        if (!isset($profiles[$name]) || !is_array($profiles[$name])) {
            $profiles[$name] = [];
        }
        if (isset($parts[1]) && strtolower($parts[1]) === 'reset') {
            unset($profiles[$name]['ui']);
            save_profiles($profiles);
            return true;
        }
        if (count($parts) < 3) {
            return true;
        }
        $target = strtolower(trim($parts[1]));
        $value = trim($parts[2]);
        $allowed = ['input', 'center', 'input-text', 'center-text', 'input-hover', 'center-hover', 'input-opacity', 'center-opacity', 'img-bg', 'img-hover', 'send-bg', 'send-hover', 'exit-hover', 'img-icon', 'img-icon-hover', 'send-icon', 'send-icon-hover', 'exit-icon', 'exit-icon-hover'];
        $validValue = str_ends_with($target, '-opacity')
            ? is_numeric($value) && (float)$value >= 0 && (float)$value <= 1
            : valid_ui_value($value);
        if (in_array($target, $allowed, true) && $validValue) {
            if (!isset($profiles[$name]['ui']) || !is_array($profiles[$name]['ui'])) {
                $profiles[$name]['ui'] = [];
            }
            $profiles[$name]['ui'][$target] = $value;
            save_profiles($profiles);
        }
        return true;
    }

    if (!can_moderate($name)) {
        return false;
    }

    if ($command === 'op' || $command === 'ope' || $command === 'ad' || $command === 'ade') {
        if (!is_admin($name) || !isset($parts[1])) {
            return true;
        }
        $target = trim($parts[1]);
        if ($target === '' || $target === 'Kuzhen') {
            return true;
        }
        $profiles = load_profiles();
        if (($command === 'op' || $command === 'ope') && is_admin($target, $profiles)) {
            return true;
        }
        if (!isset($profiles[$target]) || !is_array($profiles[$target])) {
            $profiles[$target] = [];
        }
        if ($command === 'op') {
            $profiles[$target]['role'] = 'operator';
            append_system_message('Користувача ' . $target . ' призначено оператором.');
        } elseif ($command === 'ope') {
            if (($profiles[$target]['role'] ?? '') === 'operator') {
                unset($profiles[$target]['role']);
                append_system_message('Операторські права користувача ' . $target . ' знято.');
            }
        } elseif ($command === 'ad') {
            $profiles[$target]['role'] = 'admin';
            append_system_message('Користувача ' . $target . ' призначено адміністратором.');
        } elseif ($command === 'ade') {
            if (($profiles[$target]['role'] ?? '') === 'admin') {
                unset($profiles[$target]['role']);
                append_system_message('Адміністративні права користувача ' . $target . ' знято.');
            }
        }
        save_profiles($profiles);
        return true;
    }

    if ($command === 'clear' && isset($parts[1])) {
        $clearType = strtolower($parts[1]);
        if ($clearType === 'a' || $clearType === 'all') {
            file_put_contents('log.html', '', LOCK_EX);
        } elseif ($clearType === 's') {
            $log = file_exists('log.html') ? file_get_contents('log.html') : '';
            $log = preg_replace('/<div\b[^>]*class=[\'\"][^\'\"]*\bsystem-msg\b[^\'\"]*[\'\"][^>]*>.*?<\/div>\s*/is', '', $log);
            file_put_contents('log.html', $log, LOCK_EX);
        }
        return true;
    }

    if ($command === 'kick' && isset($parts[1])) {
        $target = trim($parts[1]);
        $profiles = load_profiles();
        $protectedTarget = $target === 'Kuzhen' || (is_operator($name, $profiles) && is_admin($target, $profiles));
        if ($target !== '' && $target !== $name && !$protectedTarget) {
            $kicked = load_json_file('kicked.json');
            $kicked[$target] = time();
            file_put_contents('kicked.json', json_encode($kicked), LOCK_EX);
            remove_online_user($target);
            append_system_message('Користувача ' . $target . ' було відключено адміністратором.');
        }
        return true;
    }

    if ($command === 'style' && count($parts) >= 3) {
        if (!is_admin($name)) {
            return true;
        }
        $allowedTypes = ['name', 'text', 'a', 'block', 'border', 'time', 'all'];
        $profiles = load_profiles();
        if (in_array(strtolower($parts[1]), $allowedTypes, true)) {
            $target = $name;
            $styleType = strtolower(trim($parts[1]));
            $color = trim($parts[2]);
            $secondColor = isset($parts[3]) ? trim($parts[3]) : '';
            $gradientAngle = isset($parts[4]) ? trim($parts[4]) : '';
        } else {
            $target = trim($parts[1]);
            $styleType = strtolower(trim($parts[2]));
            $color = trim($parts[3]);
            $secondColor = isset($parts[4]) ? trim($parts[4]) : '';
            $gradientAngle = isset($parts[5]) ? trim($parts[5]) : '';
        }
        if ($styleType === 'block' && $secondColor !== '' && $gradientAngle !== '') {
            if (valid_color($color) && valid_color($secondColor) && preg_match('/^(?:[0-9]+(?:\.[0-9]+)?deg|to\s+[a-z\s]+)$/i', $gradientAngle)) {
                $color = 'linear-gradient(' . $gradientAngle . ', ' . $color . ' 0%, ' . $secondColor . ' 100%)';
            } else {
                return true;
            }
        }
        $isGradient = $styleType === 'block' && valid_gradient($color);
        $isValidStyle = strtolower($color) === 'none' || valid_color($color) || $isGradient;
        if ($target !== '' && in_array($styleType, $allowedTypes, true) && $isValidStyle) {
            if (!isset($profiles[$target]) || !is_array($profiles[$target])) {
                $profiles[$target] = [];
            }
            if (!isset($profiles[$target]['styles']) || !is_array($profiles[$target]['styles'])) {
                $profiles[$target]['styles'] = [];
            }
            $styleKeys = $styleType === 'all' ? ['name', 'text', 'a', 'block', 'border', 'time'] : [$styleType];
            foreach ($styleKeys as $styleKey) {
                if (strtolower($color) === 'none') {
                    unset($profiles[$target]['styles'][$styleKey]);
                } else {
                    $profiles[$target]['styles'][$styleKey] = $color;
                }
            }
            save_profiles($profiles);
            append_system_message('Стиль користувача ' . $target . ' оновлено.');
        }
        return true;
    }

    return false;
}

if(isset($_SESSION['name'])){
    $text = isset($_POST['text']) ? $_POST['text'] : '';
    $name = $_SESSION['name'];
    $kicked = load_json_file('kicked.json');
    if (isset($kicked[$name])) {
        http_response_code(403);
        exit;
    }
    $commandResult = handle_command(trim($text), $name);
    if ($commandResult !== false) {
        header('Content-Type: application/json; charset=UTF-8');
        if (is_string($commandResult)) {
            echo json_encode(['private' => true, 'html' => $commandResult], JSON_UNESCAPED_UNICODE);
        } else {
            echo json_encode(['refreshUi' => $text !== '' && str_starts_with(strtolower(trim($text)), 'ui')], JSON_UNESCAPED_UNICODE);
        }
        exit;
    }
    $safeName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
    $avatarMarkup = avatar_markup_for_user($name);
    $styleAttributes = htmlspecialchars(style_attributes($name), ENT_QUOTES, 'UTF-8');

    $fp = fopen("log.html", 'a');
    
    fwrite($fp, "
    <div class='msgln blockms' data-user='".$safeName."' style='".$styleAttributes."'>
        <span class='blockms-name'><b>".$safeName."</b></span>
        <span class='blockms-text'>".linkifyText($text)."</span><br>
        <span class='blockms-time'>(".date("g:i A").")</span>
    </div>\n
    ");
    
    fclose($fp);
}
?>