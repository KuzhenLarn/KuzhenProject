<?php
session_start();
require_once 'common.php';

if (!isset($_SESSION['name'])) {
    http_response_code(403);
    exit;
}

$profiles = load_profiles();
$name = $_SESSION['name'];

if (isset($_GET['avatars'])) {
    header('Content-Type: application/json; charset=UTF-8');
    $avatars = [];
    foreach ($profiles as $profileName => $profile) {
        $avatar = avatar_url_for_user($profileName, $profiles);
        if ($avatar !== '') {
            $avatars[$profileName] = $avatar;
        }
    }
    echo json_encode($avatars, JSON_UNESCAPED_UNICODE);
    exit;
}

if (isset($_GET['styles'])) {
    header('Content-Type: application/json; charset=UTF-8');
    $styles = [];
    foreach ($profiles as $profileName => $profile) {
        $styles[$profileName] = user_styles($profileName, $profiles);
    }
    $styles['Kuzhen'] = user_styles('Kuzhen', $profiles);
    echo json_encode($styles, JSON_UNESCAPED_UNICODE);
    exit;
}

if (isset($_GET['ui'])) {
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(ui_styles($name, $profiles), JSON_UNESCAPED_UNICODE);
    exit;
}

if (isset($_GET['online'])) {
    header('Content-Type: application/json; charset=UTF-8');
    $online = load_json_file('online.json');
    $result = [];
    foreach ($online as $onlineName => $lastActive) {
        if (time() - (int)$lastActive <= 20) {
            $avatar = avatar_url_for_user($onlineName, $profiles);
            $result[] = [
                'name' => $onlineName,
                'avatar' => $avatar !== '' ? $avatar : 'uploads/none.jpg'
            ];
        }
    }
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['avatar'])) {
    http_response_code(400);
    exit;
}

$file = $_FILES['avatar'];
if ($file['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo 'Не вдалося завантажити аватарку.';
    exit;
}

$imageInfo = @getimagesize($file['tmp_name']);
if ($imageInfo === false) {
    http_response_code(400);
    echo 'Файл не є підтримуваним зображенням.';
    exit;
}

$mimeExtensions = [
    'image/jpeg' => 'jpg',
    'image/png' => 'png',
    'image/gif' => 'gif',
    'image/webp' => 'webp'
];
$mimeType = isset($imageInfo['mime']) ? $imageInfo['mime'] : '';
if (!isset($mimeExtensions[$mimeType])) {
    http_response_code(400);
    echo 'Підтримуються лише JPG, PNG, GIF або WebP.';
    exit;
}

$avatarFile = 'avatar_' . hash('sha256', $name) . '.' . $mimeExtensions[$mimeType];
$avatarPath = 'uploads/avatars/' . $avatarFile;

$saved = move_uploaded_file($file['tmp_name'], $avatarPath);

if (!$saved) {
    http_response_code(500);
    echo 'Не вдалося зберегти аватарку.';
    exit;
}

$profiles[$name] = array_merge(
    isset($profiles[$name]) && is_array($profiles[$name]) ? $profiles[$name] : [],
    ['avatar' => $avatarFile]
);
if (file_put_contents('profiles.json', json_encode($profiles, JSON_UNESCAPED_UNICODE), LOCK_EX) === false) {
    http_response_code(500);
    echo 'Не вдалося зберегти дані профілю.';
    exit;
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode(['avatar' => 'uploads/avatars/' . $avatarFile], JSON_UNESCAPED_UNICODE);
?>
