<?php
session_start();
require_once 'common.php';
if(isset($_SESSION['name'])){
    $name = $_SESSION['name'];
    $file = "online.json";
    $users = file_exists($file) ? json_decode(file_get_contents($file), true) : [];

    $kicked = load_json_file('kicked.json');
    if (isset($kicked[$name])) {
        unset($kicked[$name]);
        file_put_contents('kicked.json', json_encode($kicked), LOCK_EX);
        unset($users[$name]);
        file_put_contents($file, json_encode($users), LOCK_EX);
        session_destroy();
        http_response_code(403);
        exit;
    }
    
    $now = time();
    $users[$name] = $now;

    $timeout = 20; 
    $changed = false;

    foreach($users as $u => $last_active) {
        if ($now - $last_active > $timeout) {
            unset($users[$u]);
            $changed = true;
            
            $escapedUser = htmlspecialchars($u, ENT_QUOTES, 'UTF-8');
            $fp = fopen("log.html", 'a');
            fwrite($fp, "<div class='msgln system-msg' data-user='".$escapedUser."' data-event='timeout'><i>Користувач <b>". $escapedUser ."</b> відключився (таймаут).</i><br></div>\n");
            fclose($fp);
        }
    }

    file_put_contents($file, json_encode($users));
}
?>