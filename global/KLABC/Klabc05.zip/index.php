<?php
session_start();
require_once 'common.php';
$login_error = "";
$needsPassword = false;
$loginNameValue = '';
$savedName = isset($_COOKIE['klabc_profile_name']) ? trim($_COOKIE['klabc_profile_name']) : '';
$quickAvailable = false;

$savedProfile = $savedName !== '' ? load_profiles() : [];
if ($savedName !== '') {
    if (!isset($savedProfile[$savedName])) {
        $quickAvailable = true;
    } else {
        $savedAccount = $savedProfile[$savedName];
        $quickAvailable = !isset($savedAccount['password_hash']) || has_trusted_login($savedName, $savedAccount);
    }
}

if(isset($_POST['enter']) || isset($_POST['quick_enter'])){
    $submittedName = isset($_POST['quick_enter']) ? $savedName : (isset($_POST['name']) ? $_POST['name'] : '');
    if(trim($submittedName) != ""){
        $name = stripslashes(preg_replace('/\s+/u', '', trim($submittedName)));
        $loginNameValue = $name;
        $profiles = load_profiles();
        $profile = isset($profiles[$name]) && is_array($profiles[$name]) ? $profiles[$name] : [];
        $passwordHash = isset($profile['password_hash']) ? $profile['password_hash'] : '';
        $trustedLogin = has_trusted_login($name, $profile);
        $passwordValid = isset($_POST['password']) && password_verify($_POST['password'], $passwordHash);
        if ($passwordHash !== '' && !$trustedLogin && !$passwordValid) {
            $login_error = "Для цього нікнейма потрібен пароль.";
            $needsPassword = true;
            $quickAvailable = false;
        } else {
        
        $now = time();
        $users = [];
        if (file_exists("online.json")) {
            $content = file_get_contents("online.json");
            $decoded = json_decode($content, true);
            if (is_array($decoded)) {
                $users = $decoded;
            }
        }
        
        foreach($users as $u => $last_active) {
            if ($now - $last_active > 10) {
                unset($users[$u]);
            }
        }
        
        if (isset($users[$name])) {
            $login_error = "Ім'я '$name' вже використовується в чаті!";
        } else {
            $_SESSION['name'] = $name;
            if ($passwordValid) {
                issue_login_token($name, $profile);
                $profiles[$name] = $profile;
                save_profiles($profiles);
            }
            setcookie('klabc_profile_name', $name, time() + 31536000, '/', '', false, true);
            $users[$name] = $now;
            file_put_contents("online.json", json_encode($users));
            
            $escapedName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
            $fp = fopen("log.html", 'a');
            fwrite($fp, "<div class='msgln system-msg' data-user='".$escapedName."' data-event='join'><i>Користувач <b>". $escapedName ."</b> приєднався до чату.</i><br></div>\n");
            fclose($fp);
            header('Location: index.php');
            exit;
        }
        }
    }
}

if(isset($_GET['logout'])){
    $name = isset($_SESSION['name']) ? $_SESSION['name'] : '';
    $escapedName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
    $fp = fopen("log.html", 'a');
    fwrite($fp, "<div class='msgln system-msg' data-user='".$escapedName."' data-event='logout'><i>Користувач <b>". $escapedName ."</b> виходить з чату.</i><br></div>\n");
    fclose($fp);
    
    if(file_exists("online.json")) {
        $users = json_decode(file_get_contents("online.json"), true);
        unset($users[$name]);
        file_put_contents("online.json", json_encode($users));
    }
    
    session_destroy();
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ua">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Klabc Chat</title>
    <link type="text/css" rel="stylesheet" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="icon" href="https://github.com/KuzhenLarn/KuzhenProject/blob/main/img/ico_KLOldApp.png?raw=true" type="image/png">
    
</head>
<body>

<?php if(!isset($_SESSION['name'])): ?>
    <div id="login-div">
        <img src="https://github.com/KuzhenLarn/KuzhenProject/blob/main/img/Klabc.png?raw=true" alt="Klabc" id="login-img">
        <form id="login-form" action="index.php" method="post">
            <?php if($needsPassword): ?>
                <input type="hidden" name="name" value="<?php echo htmlspecialchars($loginNameValue, ENT_QUOTES, 'UTF-8'); ?>" />
                <input type="password" name="password" id="login-password" placeholder="Введіть пароль" autocomplete="current-password" autofocus required />
                <input type="hidden" name="password_step" value="1" />
            <?php else: ?>
                <input type="text" name="name" id="login-name" placeholder="Введіть ваше ім'я" maxlength="10" oninput="this.value=this.value.replace(/\s/g,'')" value="<?php echo htmlspecialchars($loginNameValue, ENT_QUOTES, 'UTF-8'); ?>" required />
            <?php endif; ?>
            <div style="display: flex;align-items: center;justify-content: center;">
            <?php if($login_error != "") echo "<div id='login-error'>$login_error</div>"; ?>
            <input type="submit" name="enter" id="login-enter" value="<?php echo $needsPassword ? 'Увійти' : 'Далі'; ?>"/>
            <?php if($needsPassword): ?>
                <a href="index.php" id="login-back">Назад</a>
            <?php endif; ?>
            <?php if($quickAvailable && !$needsPassword): ?>
                <input type="submit" name="quick_enter" id="quick-enter" value="Увійти як <?php echo htmlspecialchars($savedName, ENT_QUOTES, 'UTF-8'); ?>" formnovalidate />
            <?php endif; ?>
            </div>
        </form>
    </div>
    <p style="color:white; position:fixed;top:0;left:10;" id="text-version">0.5</p>
<?php else: ?>

    <div id="chat-global-div">
        <div id="chat-top-div">
            <div id="online-avatars" aria-label="Онлайн"></div>
            <p class="welcome" id="chat-top-welcome"><b><?php echo htmlspecialchars($_SESSION['name'], ENT_QUOTES, 'UTF-8'); ?></b></p>
            <p id="chat-top-chat-name">Глобальний Чат KLabc</p>
            <button type="button" id="profile-avatar-btn" title="Завантажити аватарку">
                <?php echo profile_avatar_markup_for_user($_SESSION['name']); ?>
            </button>

            <input type="file" id="profile-avatar-upload" accept="image/jpeg,image/png,image/gif,image/webp" hidden>
            <input type="button" id="chat-exit" value="" />
        </div>
        
        <div id="chat-center-div">
            <?php 
            if(file_exists("log.html") && filesize("log.html") > 0){
                $handle = fopen("log.html", "r");
                $contents = fread($handle, filesize("log.html"));
                fclose($handle);
                echo $contents;
            }
            ?>
        </div>

        <div id="media-overlay" role="dialog" aria-modal="true" aria-label="Перегляд зображення" hidden>
            <img id="media-overlay-image" src="" alt="Перегляд зображення">
        </div>
        
        <button type="button" id="scroll-bottom-btn" style="display: none;">🔻хтось написав🔻</button>
        
        <form name="message" action="" id="chat-form">
        <div id="chat-input-div">
            <input type="file" id="image-upload" style="display: none;" />
            <button type="button" id="chat-img-btn" title="Відправити файл"></button>
            <textarea name="usermsg" id="chat-input" placeholder="Текст..." autocomplete="off"></textarea>
            <input name="submitmsg" type="submit" id="chat-enter" value="" />
        </div>
        </form>
    </div>

    <script>
$(document).ready(function(){
    var currentUser = <?php echo json_encode($_SESSION['name'], JSON_UNESCAPED_UNICODE); ?>;
    var firstLoad = true;
    var lastLogContent = "";
    var avatarMap = {};
    var styleMap = {};
    var uiMap = {};
    var messageHistory = JSON.parse(localStorage.getItem('klabc_message_history') || '[]');
    var historyIndex = messageHistory.length;

    $("#chat-exit").click(function(){
        var exit = confirm("Ви впевнені?");
        if(exit){
            window.location = 'index.php?logout=true';
        }
    });

    function normalizeSystemMessages(div) {
        div.find('.msgln').each(function() {
            var $item = $(this);
            var text = $item.text().trim();
            if ($item.hasClass('system-msg') || ($item.find('i').length && $item.find('.blockms-name').length === 0)) {
                $item.addClass('system-msg');
            }
        });

        div.find('.msgln.system-msg').each(function() {
            var $this = $(this);
            var user = $this.data('user') || $this.find('i b').first().text().trim();
            var $next = $this.nextAll('.msgln').first();
            if ($next.length && $next.hasClass('system-msg')) {
                var nextUser = $next.data('user') || $next.find('i b').first().text().trim();
                if (user !== '' && user === nextUser) {
                    $this.remove();
                }
            }
        });
    }

    function convertLinks(div) {
        var urlPattern = /(\b(?:https?:\/\/|www\.)[^\s<]+)/gi;
        div.find('.blockms-text').each(function() {
            var $this = $(this);
            var html = $this.html();
            if (html.indexOf('<a') !== -1) {
                return;
            }
            var newHtml = html.replace(urlPattern, function(match) {
                var href = /^www\./i.test(match) ? 'http://' + match : match;
                return '<a href="' + href + '" target="_blank" rel="noopener noreferrer">' + match + '</a>';
            });
            if (newHtml !== html) {
                $this.html(newHtml);
            }
        });
    }

    function refreshOnlineAvatars() {
        $.getJSON("profile.php?online=1", function(users) {
            var online = $("#online-avatars").empty();
            $.each(users, function(_, user) {
                if (user.avatar) {
                    $('<img>', {
                        src: user.avatar,
                        alt: user.name,
                        title: user.name,
                        class: 'online-avatar'
                    }).appendTo(online);
                }
            });
        });
    }

    function uploadAvatar(file) {
        if (!file) {
            return;
        }
        var formData = new FormData();
        formData.append('avatar', file);
        $.ajax({
            url: 'profile.php',
            data: formData,
            contentType: false,
            processData: false,
            type: 'POST',
            success: function(response) {
                $("#profile-avatar-btn").html($('<img>', {src: response.avatar, alt: 'Моя аватарка'}));
                refreshOnlineAvatars();
                loadAvatars();
                loadLog();
            },
            error: function(xhr) {
                alert(xhr.responseText || "Не вдалося завантажити аватарку.");
            }
        });
    }

    function showPrivateHelp(response) {
        $(response.html).appendTo('#chat-center-div');
        var div = $('#chat-center-div');
        div.scrollTop(div[0].scrollHeight);
    }

    function openMediaPreview(image) {
        $("#media-overlay-image").attr({src: image.src, alt: image.alt || 'Перегляд зображення'});
        $("#media-overlay").prop('hidden', false);
    }

    $(document).on('click', '.chat-image, .chat-image-link img', function(e) {
        e.preventDefault();
        e.stopPropagation();
        openMediaPreview(this);
    });

    $(document).on('click', '#media-overlay', function() {
        $(this).prop('hidden', true);
        $("#media-overlay-image").attr('src', '');
    });

    function decorateMessageAvatars(div) {
        div.find('.blockms').each(function() {
            var item = $(this);
            var author = item.find('.blockms-name b').text().trim();
            if (author && author !== currentUser && avatarMap[author] && item.find('.blockms-avatar').length === 0) {
                $('<img>', {
                    src: avatarMap[author],
                    alt: 'Аватар ' + author,
                    class: 'blockms-avatar'
                }).prependTo(item.find('.blockms-name'));
            }
        });
    }

    function loadAvatars() {
        $.getJSON('profile.php?avatars=1', function(avatars) {
            avatarMap = avatars;
            decorateMessageAvatars($('#chat-center-div'));
        });
    }

    function applyUserStyles(div) {
        div.find('.blockms').each(function() {
            var item = $(this);
            var author = item.attr('data-user') || item.find('.blockms-name b').text().trim();
            var styles = styleMap[author] || {};
            var block = styles.block || 'rgb(255, 223, 202)';
            var blockIsGradient = /^linear-gradient\(/i.test(block);
            item.css({
                '--user-name-color': styles.name || 'rgb(255, 223, 202)',
                '--user-text-color': styles.text || 'inherit',
                '--user-link-color': styles.a || '#1e5a75',
                '--user-block-color': blockIsGradient ? 'transparent' : block,
                '--user-block-background': blockIsGradient ? block : 'rgb(255, 223, 202)',
                '--user-border-color': styles.border || 'transparent',
                '--user-time-color': styles.time || '#444'
            });
        });
    }

    function loadStyles() {
        $.getJSON('profile.php?styles=1', function(styles) {
            styleMap = styles;
            applyUserStyles($('#chat-center-div'));
        });
    }

    function uiValue(value, fallback) {
        return value || fallback;
    }

    function applyUiStyles(ui) {
        uiMap = ui || {};
        var input = $('#chat-input-div');
        var center = $('#chat-center-div');
        var inputText = $('#chat-input');
        var imgButton = $('#chat-img-btn');
        var sendButton = $('#chat-enter');
        var inputBackground = uiValue(ui.input, 'rgb(255, 223, 202)');
        var centerBackground = uiValue(ui.center, 'rgb(83, 73, 65)');
        function backgroundValue(value, opacity) {
            if (!/^https?:/i.test(value)) return value;
            var darkness = Number.isFinite(Number(opacity)) ? Number(opacity) : 0;
            return 'linear-gradient(rgba(0,0,0,' + darkness + '), rgba(0,0,0,' + darkness + ')), url("' + value + '") center / cover';
        }
        var inputBackgroundStyle = backgroundValue(inputBackground, ui['input-opacity']);
        var centerBackgroundStyle = backgroundValue(centerBackground, ui['center-opacity']);
        input.css('background', inputBackgroundStyle);
        center.css('background', centerBackgroundStyle);
        inputText.css('color', ui['input-text'] || '');
        center.css('color', ui['center-text'] || '');
        imgButton.css('background-color', uiValue(ui['img-bg'], inputBackground));
        sendButton.css('background-color', uiValue(ui['send-bg'], inputBackground));
        var imgIcon = ui['img-icon'] ? 'url("' + ui['img-icon'] + '")' : '';
        var sendIcon = ui['send-icon'] ? 'url("' + ui['send-icon'] + '")' : '';
        var exitIcon = ui['exit-icon'] ? 'url("' + ui['exit-icon'] + '")' : '';
        var imgHoverIcon = ui['img-icon-hover'] ? 'url("' + ui['img-icon-hover'] + '")' : imgIcon;
        var sendHoverIcon = ui['send-icon-hover'] ? 'url("' + ui['send-icon-hover'] + '")' : sendIcon;
        var exitHoverIcon = ui['exit-icon-hover'] ? 'url("' + ui['exit-icon-hover'] + '")' : exitIcon;
        if (imgIcon) imgButton.css('background-image', imgIcon);
        if (sendIcon) sendButton.css('background-image', sendIcon);
        if (exitIcon) $('#chat-exit').css('background-image', exitIcon);
        input.off('.klabcUi').on('mouseenter.klabcUi', function() { input.css('background', uiValue(ui['input-hover'], inputBackground)); }).on('mouseleave.klabcUi', function() { input.css('background', inputBackground); });
        center.off('.klabcUi').on('mouseenter.klabcUi', function() { center.css('background', uiValue(ui['center-hover'], centerBackground)); }).on('mouseleave.klabcUi', function() { center.css('background', centerBackground); });
        imgButton.off('.klabcUi').on('mouseenter.klabcUi', function() { imgButton.css({'background-color': uiValue(ui['img-hover'], uiValue(ui['input-hover'], 'black')), 'background-image': imgHoverIcon || ''}); }).on('mouseleave.klabcUi', function() { imgButton.css({'background-color': uiValue(ui['img-bg'], inputBackground), 'background-image': imgIcon || ''}); });
        sendButton.off('.klabcUi').on('mouseenter.klabcUi', function() { sendButton.css({'background-color': uiValue(ui['send-hover'], uiValue(ui['input-hover'], 'black')), 'background-image': sendHoverIcon || ''}); }).on('mouseleave.klabcUi', function() { sendButton.css({'background-color': uiValue(ui['send-bg'], inputBackground), 'background-image': sendIcon || ''}); });
        $('#chat-exit').off('.klabcUi').on('mouseenter.klabcUi', function() { $('#chat-exit').css({'background-color': uiValue(ui['exit-hover'], 'transparent'), 'background-image': exitHoverIcon || ''}); }).on('mouseleave.klabcUi', function() { $('#chat-exit').css({'background-color': 'transparent', 'background-image': exitIcon || ''}); });
    }

    function loadUiStyles() {
        $.getJSON('profile.php?ui=1', applyUiStyles);
    }

    function loadLog(){
        var div = $("#chat-center-div");
        if(div.length === 0) return;
        
        var raw = div[0];
        var wasAtBottom = firstLoad || (raw.scrollHeight - raw.scrollTop - raw.clientHeight) < 100;

        $.ajax({
            url: "log.html",
            cache: false,
            success: function(html){
                if (html === lastLogContent) {
                    return;
                }
                lastLogContent = html;

                div.html(html);
                normalizeSystemMessages(div);
                convertLinks(div);
                loadAvatars();
                loadStyles();
                
                div.find(".msgln").each(function() {
                    var author = $(this).find(".blockms-name b").text(); 
                    if (author === currentUser) {
                        $(this).addClass("msg-right");
                    } else if (author !== "") {
                        $(this).addClass("msg-left");
                    }
                });
                
                if(wasAtBottom) {
                    div.scrollTop(raw.scrollHeight);
                    div.find('img').on('load', function() {
                        div.scrollTop(raw.scrollHeight);
                    });
                    $("#scroll-bottom-btn").fadeOut();
                } else {
                    if (!firstLoad) {
                        $("#scroll-bottom-btn").fadeIn();
                    }
                }
                
                firstLoad = false;
            }
        });
    }
    
    $("#chat-center-div").scroll(function() {
        var raw = this;
        var atBottom = (raw.scrollHeight - raw.scrollTop - raw.clientHeight) < 100;
        if (atBottom) {
            $("#scroll-bottom-btn").fadeOut();
        }
    });

    $("#scroll-bottom-btn").click(function() {
        var div = $("#chat-center-div");
        div.animate({ scrollTop: div[0].scrollHeight }, 300);
        $(this).fadeOut();
    });
    
    setInterval(loadLog, 1000);
    refreshOnlineAvatars();
    loadAvatars();
    loadStyles();
    loadUiStyles();
    setInterval(refreshOnlineAvatars, 5000);
    
    setInterval(function(){
        $.post("ping.php").fail(function(xhr) {
            if (xhr.status === 403) {
                window.location = 'index.php';
            }
        });
    }, 5000);

    $("#chat-img-btn").click(function(){
        $("#image-upload").click();
    });

    $("#profile-avatar-btn").click(function(){
        $("#profile-avatar-upload").click();
    });

    $("#profile-avatar-upload").change(function(){
        uploadAvatar(this.files[0]);
        $(this).val('');
    });

    $("#image-upload").change(function(){
        var file_data = $(this).prop('files')[0];
        if(file_data) {
            var form_data = new FormData();
            form_data.append('file', file_data);
            
            $.ajax({
                url: 'upload.php',
                dataType: 'text',
                cache: false,
                contentType: false,
                processData: false,
                data: form_data,
                type: 'post',
                success: function(response){
                    $("#image-upload").val('');
                }
            });
        }
    });

    var baseComposerHeight = $("#chat-input-div").height();

    function resizeComposer() {
        var input = $("#chat-input");
        var composer = $("#chat-input-div");
        var value = input.val();
        var isSingleLine = value.indexOf('\n') === -1;
        if (isSingleLine) {
            input.css({
                'line-height': '',
                'padding-top': '',
                'padding-bottom': ''
            });
            input.height(baseComposerHeight);
            composer.height(baseComposerHeight);
            $("#chat-enter, #chat-img-btn").height(baseComposerHeight);
            return;
        }

        input.height('auto');
        input.css({
            'padding-top': '0px',
            'padding-bottom': '0px',
            'line-height': 'normal'
        });
        var nextHeight = Math.max(baseComposerHeight, Math.min(input[0].scrollHeight, window.innerHeight * 0.4));
        input.height(nextHeight);
        composer.height(nextHeight);
        $("#chat-enter, #chat-img-btn").height(nextHeight);
    }

    function sendMessage() {
        var clientmsg = $("#chat-input").val();

        if(clientmsg.trim() === "") {
            return;
        }

        messageHistory = messageHistory.filter(function(message) {
            return message !== clientmsg;
        });
        messageHistory.push(clientmsg);
        localStorage.setItem('klabc_message_history', JSON.stringify(messageHistory));
        historyIndex = messageHistory.length;
        $.post("post.php", {text: clientmsg}, function(response) {
            if (response && response.private) {
                showPrivateHelp(response);
            }
            if (response && response.refreshUi) {
                loadUiStyles();
            }
        }, 'json');
        $("#chat-input").val("");
        resizeComposer();
    }

    $("#chat-form").submit(function(e){
        e.preventDefault();
        e.stopPropagation();
        sendMessage();
    });

    $("#chat-input").on("keydown", function(e) {
        if (e.key === 'Enter' && e.shiftKey) {
            e.stopPropagation();
            window.setTimeout(resizeComposer, 0);
            return;
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            e.stopPropagation();
            sendMessage();
            return;
        }
        if (e.ctrlKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
            e.preventDefault();
            if (messageHistory.length === 0) {
                return;
            }
            historyIndex += e.key === 'ArrowUp' ? -1 : 1;
            historyIndex = Math.max(0, Math.min(historyIndex, messageHistory.length));
            $(this).val(historyIndex === messageHistory.length ? '' : messageHistory[historyIndex]);
            resizeComposer();
        }
    });

    $("#chat-input").on("input", resizeComposer);
    resizeComposer();

    $("#chat-input").on("paste", function(e) {
        var clipboardData = e.originalEvent.clipboardData;
        
        if (clipboardData && clipboardData.items) {
            for (var i = 0; i < clipboardData.items.length; i++) {
                var item = clipboardData.items[i];
                
                if (item.type.indexOf("image") !== -1) {
                    var file_data = item.getAsFile();
                    
                    if (file_data) {
                        var form_data = new FormData();
                        form_data.append('file', file_data);
                        
                        $.ajax({
                            url: 'upload.php',
                            dataType: 'text',
                            cache: false,
                            contentType: false,
                            processData: false,
                            data: form_data,
                            type: 'post',
                            success: function(response){
                                loadLog();
                            }
                        });
                        
                        e.preventDefault();
                    }
                }
            }
        }
    });
});
    </script>
<?php endif; ?>

</body>
</html>