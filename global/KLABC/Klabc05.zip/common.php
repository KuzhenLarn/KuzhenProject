<?php
function load_json_file($file) {
    if (!file_exists($file)) {
        return [];
    }

    $decoded = json_decode(file_get_contents($file), true);
    return is_array($decoded) ? $decoded : [];
}

function load_profiles() {
    return load_json_file('profiles.json');
}

function save_profiles($profiles) {
    return file_put_contents('profiles.json', json_encode($profiles, JSON_UNESCAPED_UNICODE), LOCK_EX) !== false;
}

function valid_ui_value($value) {
    return valid_color($value)
        || preg_match('/^https?:\/\/[^\s]+\.(?:png|jpe?g|gif|webp)(?:\?[^\s]*)?$/i', $value) === 1;
}

function ui_styles($name, $profiles = null) {
    $profiles = $profiles === null ? load_profiles() : $profiles;
    return isset($profiles[$name]['ui']) && is_array($profiles[$name]['ui']) ? $profiles[$name]['ui'] : [];
}

function has_trusted_login($name, $profile) {
    $token = isset($_COOKIE['klabc_profile_token']) ? $_COOKIE['klabc_profile_token'] : '';
    $tokenHash = isset($profile['login_token_hash']) ? $profile['login_token_hash'] : '';
    return $token !== '' && $tokenHash !== '' && password_verify($token, $tokenHash);
}

function issue_login_token($name, &$profile) {
    $token = bin2hex(random_bytes(32));
    $profile['login_token_hash'] = password_hash($token, PASSWORD_DEFAULT);
    setcookie('klabc_profile_token', $token, time() + 31536000, '/', '', false, true);
}

function is_admin($name, $profiles = null) {
    if ($name === 'Kuzhen') {
        return true;
    }
    $profiles = $profiles === null ? load_profiles() : $profiles;
    return isset($profiles[$name]['role']) && $profiles[$name]['role'] === 'admin';
}

function is_operator($name, $profiles = null) {
    if (is_admin($name, $profiles)) {
        return false;
    }
    $profiles = $profiles === null ? load_profiles() : $profiles;
    return isset($profiles[$name]['role']) && $profiles[$name]['role'] === 'operator';
}

function can_moderate($name, $profiles = null) {
    return is_admin($name) || is_operator($name, $profiles);
}

function is_privileged_target($name, $profiles = null) {
    return is_admin($name) || is_operator($name, $profiles);
}

function valid_color($color) {
    return preg_match('/^(#[0-9a-fA-F]{3,8}|[a-zA-Z]+)$/', $color) === 1;
}

function valid_gradient($value) {
    return preg_match('/^linear-gradient\(\s*(?:[0-9]+(?:\.[0-9]+)?deg|to\s+[a-z\s]+)\s*,\s*(?:rgba?\(\s*[0-9]{1,3}\s*,\s*[0-9]{1,3}\s*,\s*[0-9]{1,3}(?:\s*,\s*(?:0|1|0?\.[0-9]+))?\s*\)|#[0-9a-fA-F]{3,8}|[a-zA-Z]+)(?:\s+[0-9]+%)?(?:\s*,\s*(?:rgba?\(\s*[0-9]{1,3}\s*,\s*[0-9]{1,3}\s*,\s*[0-9]{1,3}(?:\s*,\s*(?:0|1|0?\.[0-9]+))?\s*\)|#[0-9a-fA-F]{3,8}|[a-zA-Z]+)(?:\s+[0-9]+%)?)+\s*\)$/i', $value) === 1;
}

function user_styles($name, $profiles = null) {
    $profiles = $profiles === null ? load_profiles() : $profiles;
    $styles = isset($profiles[$name]['styles']) && is_array($profiles[$name]['styles'])
        ? $profiles[$name]['styles']
        : [];

    if (is_admin($name)) {
        $styles = array_merge([
            'name' => '#fff3e0',
            'text' => '#4a1f00',
            'block' => '#ffd180',
            'border' => '#000000'
        ], $styles);
    }

    return array_intersect_key($styles, array_flip(['name', 'text', 'block', 'border', 'time', 'a']));
}

function style_attributes($name, $profiles = null) {
    $styles = user_styles($name, $profiles);
    $attributes = [];
    if (isset($styles['name']) && valid_color($styles['name'])) {
        $attributes[] = "--user-name-color:" . $styles['name'];
    }
    if (isset($styles['text']) && valid_color($styles['text'])) {
        $attributes[] = "--user-text-color:" . $styles['text'];
    }
    if (isset($styles['a']) && valid_color($styles['a'])) {
        $attributes[] = "--user-link-color:" . $styles['a'];
    }
    if (isset($styles['block']) && valid_color($styles['block'])) {
        $attributes[] = "--user-block-color:" . $styles['block'];
    }
    if (isset($styles['block']) && valid_gradient($styles['block'])) {
        $attributes[] = "--user-block-background:" . $styles['block'];
    }
    if (isset($styles['border']) && valid_color($styles['border'])) {
        $attributes[] = "--user-border-color:" . $styles['border'];
    }
    if (isset($styles['time']) && valid_color($styles['time'])) {
        $attributes[] = "--user-time-color:" . $styles['time'];
    }
    return implode(';', $attributes);
}

function avatar_url_for_user($name, $profiles = null) {
    $profiles = $profiles === null ? load_profiles() : $profiles;
    $avatar = isset($profiles[$name]['avatar']) ? basename($profiles[$name]['avatar']) : '';
    return $avatar !== '' && file_exists('uploads/avatars/' . $avatar) ? 'uploads/avatars/' . $avatar : '';
}

function avatar_markup_for_user($name, $profiles = null) {
    $avatarUrl = avatar_url_for_user($name, $profiles);
    if ($avatarUrl === '') {
        return '';
    }

    $safeUrl = htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8');
    $safeName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
    return "<img class='blockms-avatar' src='" . $safeUrl . "' alt='Аватар " . $safeName . "'>";
}

function profile_avatar_markup_for_user($name, $profiles = null) {
    $avatarUrl = avatar_url_for_user($name, $profiles);
    if ($avatarUrl === '') {
        $avatarUrl = 'uploads/none.jpg';
    }

    $safeUrl = htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8');
    $safeName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
    return "<img class='blockms-avatar' src='" . $safeUrl . "' alt='Аватар " . $safeName . "'>";
}
?>
