<?php
session_start();
require_once 'common.php';
if(isset($_SESSION['name']) && isset($_FILES['file'])){
    
    $file = $_FILES['file'];
    $kicked = load_json_file('kicked.json');
    if (isset($kicked[$_SESSION['name']])) {
        http_response_code(403);
        exit;
    }
    $uploadDir = 'uploads/';
    
    if($file['error'] !== UPLOAD_ERR_OK) {
        $errorMsg = "Невідома помилка завантаження.";
        if($file['error'] == UPLOAD_ERR_INI_SIZE) {
            $errorMsg = "Файл занадто великий! Сервер PHP обмежив завантаження.";
        }
        $fp = fopen("log.html", 'a');
        fwrite($fp, "<div class='msgln'><i><b>Системне повідомлення:</b> $errorMsg</i><br></div>\n");
        fclose($fp);
        exit;
    }
    
    if(!is_dir($uploadDir) || !is_writable($uploadDir)) {
        $fp = fopen("log.html", 'a');
        fwrite($fp, "<div class='msgln'><i><b>Системна помилка:</b> Немає прав на запис у папку uploads!</i><br></div>\n");
        fclose($fp);
        exit;
    }
    
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    $newFileName = uniqid('file_', true) . '.' . $extension;
    $uploadPath = $uploadDir . $newFileName;
    
    if(move_uploaded_file($file['tmp_name'], $uploadPath)) {
        date_default_timezone_set('Europe/Kyiv');
        $fp = fopen("log.html", 'a');
        
        $imgExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $videoExtensions = ['mp4', 'webm', 'ogg', 'ogv', 'mov'];
        $safeName = htmlspecialchars($_SESSION['name'], ENT_QUOTES, 'UTF-8');
        $styleAttributes = htmlspecialchars(style_attributes($_SESSION['name']), ENT_QUOTES, 'UTF-8');
        
        if(in_array($extension, $imgExtensions)) {
            $chatHtml = "<img src='".$uploadPath."' class='chat-image' alt='Фото від ".$safeName."' data-media-preview>";
        } elseif (in_array($extension, $videoExtensions)) {
            $videoType = $extension === 'ogv' ? 'ogg' : $extension;
            $chatHtml = "<video class='chat-video' controls preload='metadata'><source src='".$uploadPath."' type='video/".$videoType."'>Ваш браузер не підтримує відео.</video>";
        } else {
            $origName = htmlspecialchars($file['name']);
            $chatHtml = "<a href='".$uploadPath."' target='_blank' class='chat-file-link'>📎 Файл: <b>".$origName."</b></a>";
        }
        
        fwrite($fp, "
        <div class='msgln blockms' data-user='".$safeName."' style='".$styleAttributes."'>
            <span class='blockms-name'><b>".$safeName."</b></span>
            <span class='blockms-text'>".$chatHtml."</span><br>
            <span class='blockms-time'>(".date("g:i A").")</span>
        </div>\n
        ");
        fclose($fp);
    }
}
?>
